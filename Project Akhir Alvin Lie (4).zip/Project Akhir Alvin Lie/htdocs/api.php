<?php
include 'db.php';  // Menyertakan file koneksi

// Contoh: Ambil semua transaksi
$sql = "SELECT * FROM transactions ORDER BY date_created DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Deskripsi: " . $row["description"]. " - Jumlah: " . $row["amount"]. " - Tipe: " . $row["type"]. "<br>";
    }
} else {
    echo "0 hasil";
}

$conn->close(); // Tutup koneksi
?>
